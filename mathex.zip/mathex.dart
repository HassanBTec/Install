
/**** dart pub add math_expressions  ***
*****   pubspec.yaml 		 *******
name: calc
description: A new calc.
version: 1.0.0+1


environment:
  sdk: '>=2.12.0 <3.0.0'
dependencies:
  math_expressions: ^2.2.0
*****/

import 'dart:io';

import 'dart:math' as math;
import 'package:math_expressions/math_expressions.dart';

void main(List<String> args) {

	print('Let us do something useful.');

	print('Username:');
	/*String? username = stdin.readLineSync();
	print ('=> $username');*/

	print('Password:');
	stdin.echoMode = false;
	/*String? pass = stdin.readLineSync();
	print ('=> $pass');*/

	Variable x = Variable('x'), y = Variable('y');
	Parser p = Parser();
  	Expression exp = p.parse('(x^2 + cos(y)) / 3');

	ContextModel cm = ContextModel()
    		..bindVariable(x, Number(2.0))
    		..bindVariable(y, Number(math.pi));

	double eval = exp.evaluate(EvaluationType.REAL, cm);

  	print('Expression: $exp');
  	print('Evaluated expression: $eval\n  (with context: $cm)');
}
